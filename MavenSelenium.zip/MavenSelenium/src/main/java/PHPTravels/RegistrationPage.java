package PHPTravels;

import org.testng.annotations.Test;

public class RegistrationPage extends Operations
	{
	LaunchBrowser l1=new LaunchBrowser();
	
	@Test
		public void method() throws Exception {
	
		l1.browser();
		SignUpPage();
	   driver.close();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

