package PHPTravels;

import org.testng.annotations.Test;


	public class Loginpage extends Operationslogin
	{
	LaunchBrowser l1=new LaunchBrowser();
	
	@Test
		public void method() throws Exception {
	
		l1.browser();
		Loginpage();
	
		}
	}
	
	
	

