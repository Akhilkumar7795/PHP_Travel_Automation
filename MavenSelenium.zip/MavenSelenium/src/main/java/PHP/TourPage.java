package PHP;

import org.testng.annotations.Test;

public class TourPage extends operationstour {
	
	
	
	@Test
		public void method() throws Exception {
	{
	
		LaunchBrowser l1=new LaunchBrowser();
		l1.browser();
		TourPage();
	
		}
	}}

