
public class opHotel {

}
